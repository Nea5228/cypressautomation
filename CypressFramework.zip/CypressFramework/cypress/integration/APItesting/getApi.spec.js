/// <reference types ="Cypress" />

describe('get api user tests', ()=>{

    it('get users', ()=>{

        cy.request({
            failOnStatusCode: false,

            method : 'GET',
            url : 'https://qa-practical.qa.swimlane.io:443/api/auth/user/12/token',
           headers : {
               'authorization' : "Bearer eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1laWQiOiJhRGFEdkpTMGtkdktlb3NVTyIsInVuaXF1ZV9uYW1lIjoibmFsZWUub25lbWFueXZvbmciLCJnaXZlbl9uYW1lIjoiTmFsZWUgT25lbWFueXZvbmciLCJlbWFpbCI6Im1hcmphbi5nZW9yZ2lldituYWxlZUBzd2ltbGFuZS5jb20iLCJzY29wZSI6ImV4ZWN1dGU6KiByZWFkOioiLCJqdGkiOiI4ZmFmMWQzOS00NjhhLTQ1YjYtYjUzOC01ZTg3MTU5YjU5NTUiLCJuYmYiOjE2NTE3NDQwNDksImV4cCI6MTY1MTc1ODQ0OSwiaWF0IjoxNjUxNzQ0MDQ5LCJpc3MiOiJTd2ltbGFuZSIsImF1ZCI6IlN3aW1sYW5lIn0.dcvPyImsoQMVgJS9CA9IY2LKoXdkxsk6eWclMol2So7Ec4b3-tBy-nGBJW_XyySyqu_b-wkMYo5UbYnk3mS4Ag"
            }

        }).then((res)=>{
            expect(res.status).to.eq(400)
           //expect(res.body.meta.pagination.limit).to.eq(20)
        })


    })

})