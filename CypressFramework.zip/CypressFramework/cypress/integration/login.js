//const cypress = require("cypress")

describe('Swimlane', function () 
 {
    it('Login', function() 
    {       
        cy.visit('https://qa-practical.qa.swimlane.io/') //Open website URL
        cy.wait(1000)
        cy.get("#input-1").type("nalee.onemanyvong"); //Enter Username
        cy.get("#input-2").type("Ethan@22"); //Enter Password
        cy.wait(1000)
        cy.contains("Login").click(); //Click Login button
        cy.wait(1000)
    })

    it('Create New Record', function() 
    {   
        cy.wait(1000)
        cy.get(".ngx-plus").click(); //Click on + link 
        cy.wait(1000)
        cy.get("[name='aHdR_gHQmRT8ItVTL']").type("Test First"); //Enter First name
        cy.wait(1000)  
        cy.get("[name='aHxOeHmCTIGd_hg1b']").type("Test Last");  //Enter Last Name
        cy.get("[name='aFjm80LnbJf780V6p']").type("Test city");//Enter City name
        cy.contains("Save").click();
        cy.get(".form-input:nth-child(3)").type("1h 50m");
        cy.contains("Save").click();
        //cy.get(".modal-footer > .btn").click();//



    })
  })